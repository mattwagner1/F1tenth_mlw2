#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

import numpy as np
import math
import csv
from nav_msgs.msg import Odometry
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive
from visualization_msgs.msg import Marker

def euler_yaw_from_quaternion(x, y, z, w):
        """
        Convert a quaternion into euler angles (roll, pitch, yaw)
        roll is rotation around x in radians (counterclockwise)
        pitch is rotation around y in radians (counterclockwise)
        yaw is rotation around z in radians (counterclockwise)
        """
        # modified from: https://automaticaddison.com/how-to-convert-a-quaternion-into-euler-angles-in-python/#google_vignette
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw_z = math.atan2(t3, t4)
     
        return yaw_z # in radians

class PurePursuit(Node):
    """ 
    Implement Pure Pursuit on the car
    This is just a template, you are free to implement your own node!
    """
    def __init__(self):
        super().__init__('pure_pursuit_node')
        # TODO: create ROS subscribers and publishers
        drive_topic = '/drive'

        # Subscribe to Odometry
        self.odom_subscription = self.create_subscription(
                Odometry,
                '/ego_racecar/odom',
                self.pose_callback,
                10)

        # Publish Target Waypoint
        self.waypoint_publisher = self.create_publisher(Marker, '/target_waypoint', 10)

        # Publish to drive
        self.publisher_ = self.create_publisher(AckermannDriveStamped, drive_topic, 10)
        
        self.theta = 0 # radians, current orientation of the car 90?
        self.lookahead = 20 # look ahead index
        self.waypoints = [] # load from file
        with open("/sim_ws/src/pure_pursuit/csv/waypoint_data.csv", newline='') as csvfile: # change file name
            csv_reader = csv.reader(csvfile)
            for waypoint in csv_reader:
                waypoint = [float(coord) for coord in waypoint]
                self.waypoints.append(waypoint)
        self.last_waypoint = 0 # don't look at waypoints behind you
        self.wheelbase = .25
        self.max_steer = 30.0 * np.pi / 180

    def getClosestWaypt(self, x, y, waypoints):
        # return the index of the waypoint closest to the car
        min_dist = None
        target_waypt = None
        for waypt in range(self.last_waypoint, len(waypoints)):
            waypt_x = waypoints[waypt][0]
            waypt_y = waypoints[waypt][1]
            distance = np.sqrt((waypt_x - x) ** 2 + (waypt_y - y) ** 2)
            if min_dist == None or distance < min_dist:
                min_dist = distance
                target_waypt = waypt
            elif distance > min_dist: # check this
                break
        return target_waypt

    def get_car_orientation(self, pose_msg):
        ### obtain car pose
        quaternions = pose_msg.pose.pose.orientation
        q_x = quaternions.x
        q_y = quaternions.y
        q_z = quaternions.z
        q_w = quaternions.w
        self.theta = euler_yaw_from_quaternion(q_x, q_y, q_z, q_w)

    def publish_target_waypoint(self, target_x, target_y):
        marker = Marker()
        marker.type = 2
        marker.action = 0
        marker.header.frame_id = "/map"

        marker.ns = "visualized_waypoints"

        marker.scale.x = 0.5
        marker.scale.y = 0.5
        marker.scale.z = 0.5

        marker.color.r = 0.0
        marker.color.g = 1.0
        marker.color.b = 0.0
        marker.color.a = 1.0

        marker.pose.position.z = 0.0
        marker.pose.orientation.x = 0.0
        marker.pose.orientation.y = 0.0
        marker.pose.orientation.z = 0.0
        marker.pose.orientation.w = 1.0

        marker.pose.position.x = target_x
        marker.pose.position.y = target_y

        marker.lifetime.sec = 1

        # marker_array.markers.append(marker)
        self.waypoint_publisher.publish(marker)

    def pose_callback(self, pose_msg):
        curr_x = pose_msg.pose.pose.position.x
        curr_y = pose_msg.pose.pose.position.y

        # get car orientation
        self.get_car_orientation(pose_msg)

        # TODO: find the current waypoint to track using methods mentioned in lecture
        target_waypoint = self.getClosestWaypt(curr_x, curr_y, self.waypoints) + self.lookahead

        # TODO: transform goal point to vehicle frame of reference
        target_x = self.waypoints[target_waypoint][0]
        target_y = self.waypoints[target_waypoint][1]

        # Publish target to waypoint visualizer
        self.publish_target_waypoint(target_x, target_y)

        # Rotation Matrix R
        R = np.array([[np.cos(self.theta), np.sin(self.theta)],[-np.sin(self.theta), np.cos(self.theta)]])
        transformed_coords = np.matmul(R,np.array([target_x-curr_x,target_y-curr_y]).T)
        
        goal_x = transformed_coords[0]
        goal_y = transformed_coords[1]

        # TODO: calculate curvature/steering angle
        L = np.sqrt(goal_x**2 + goal_y**2)
        curvature = 2*abs(goal_y) / L**2
        delta = math.atan2(curvature*self.wheelbase, 1.0)
        if goal_y < 0:
            delta = -delta

        # TODO: publish drive message, don't forget to limit the steering angle.
        if delta > self.max_steer:
            delta = self.max_steer
        elif delta < -self.max_steer:
            delta = -self.max_steer

        if abs(delta) <= 20:
            if abs(delta) <= 10:
                velocity = 1.5
            else:
                velocity = 1.0
        else:
            velocity = 0.5
        drive_msg = AckermannDriveStamped()
        drive_msg.drive.speed = velocity
        drive_msg.drive.steering_angle = delta
        self.publisher_.publish(drive_msg)

        # assign curr waypoint to last waypoint for next iteration
        self.last_waypoint = target_waypoint - self.lookahead

def main(args=None):
    rclpy.init(args=args)
    print("PurePursuit Initialized")
    pure_pursuit_node = PurePursuit()
    try:
        rclpy.spin(pure_pursuit_node)
    except:
        stop_msg = AckermannDriveStamped()
        stop_msg.drive.speed = 0.0    
        pure_pursuit_node.publisher_.publish(stop_msg)
        print('End of Waypoint track')
        
    pure_pursuit_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
