#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

class ReactiveFollowGap(Node):
    """ 
    Implement Wall Following on the car
    This is just a template, you are free to implement your own node!
    """
    def __init__(self):
        super().__init__('reactive_node')
        # Topics & Subs, Pubs
        lidarscan_topic = '/scan'
        drive_topic = '/drive'

        # Subscribe to LIDAR
        self.subscription = self.create_subscription(
                LaserScan,
                lidarscan_topic,
                self.lidar_callback,
                10)
        # Publish to drive
        self.publisher_ = self.create_publisher(AckermannDriveStamped, drive_topic, 10)

        # items to keep track of 
        self.bubble_size = 42 # 25
        self.t = 1.25#6 # gap distance threashold

    def remove_outliers(self, data):
        # helper function to remove outliers from a range of data
        avg = sum(data) / len(data)
        std_dev = np.std(data)
        z_scores = [(x - avg) / std_dev for x in data]
        threashold = 4
        new_data = []
        for i in range(len(data)):
            if abs(z_scores[i]) < threashold:
                new_data.append(data[i])
        return new_data

    def preprocess_lidar(self, ranges):
        """ Preprocess the LiDAR scan array. Expert implementation includes:
            1.Setting each value to the mean over some window
            2.Rejecting high values (eg. > 3m)
        """
        ranges = ranges.tolist()
        proc_ranges = ranges
        # filter out high values, nan or inf
        avg_quant = 4
        for i in range(len(ranges)):
            lwr_i = i - avg_quant
            if lwr_i < 0:
                lwr_i = 0
            upr_i = i + avg_quant
            if upr_i > len(ranges):
                upr_i = len(ranges)
            avg_range = ranges[lwr_i:upr_i]
            avg_range = self.remove_outliers(avg_range)
            avg = sum(avg_range) / len(avg_range)
            proc_ranges[i] = avg

        return proc_ranges

    def find_max_gap(self, free_space_ranges):
        """ Return the start index & end index of the max gap in free_space_ranges"""
        start = None
        end = None
        start_max = 0
        end_max = len(free_space_ranges)
        max_gap = 0
        curr_gap = 0
        for i in range(len(free_space_ranges)):
            value = free_space_ranges[i]
            if value > self.t or value == np.inf:
                if start == None:
                    # start a gap
                    start = i
                curr_gap += 1
            elif value < self.t:
                if start != None:
                    # end a gap, check if it is the largest so far
                    end = i
                    if curr_gap > max_gap + 40:
                        max_gap = curr_gap
                        start_max = start
                        end_max = end
                    # reset and look for a new gap
                    start = None
                    end = None
                    curr_gap = 0

        return (start_max, end_max)
    
    def find_best_point(self, start_i, end_i, ranges):
        """Start_i & end_i are start and end indicies of max-gap range, respectively
        Return index of best point in ranges
	    Naive: Choose the furthest point within ranges and go there
        """ 
        gap = ranges[start_i:end_i]
        return len(gap) // 2 + start_i        

    def lidar_callback(self, data):
        """ Process each LiDAR scan as per the Follow Gap algorithm & publish an AckermannDriveStamped Message"""
        ranges = data.ranges
        proc_ranges = self.preprocess_lidar(ranges)
        
        #Find closest point to LiDAR and a bubble around them
        closest_pt = proc_ranges.index(min(proc_ranges))
        lwr_bound_bubble = closest_pt-self.bubble_size
        if lwr_bound_bubble < 0:
            lwr_bound_bubble = 0
        upr_bound_bubble = closest_pt+self.bubble_size
        if upr_bound_bubble > len(proc_ranges):
            upr_bound_bubble = len(proc_ranges)

        #Eliminate all points inside 'bubble' (set them to zero) 
        for i in range(lwr_bound_bubble,upr_bound_bubble):
            proc_ranges[i] = 0

        #Find max length gap 
        (start, end) = self.find_max_gap(proc_ranges)
        
        #Find the best point in the gap 
        destination_i = self.find_best_point(start, end, proc_ranges)

        # if the closest point is far away, look further ahead than normal
        """closest_pt_ahead = min(proc_ranges[500:580])
        if closest_pt_ahead > 3:
            destination_i = max(proc_ranges[360:720])"""

        #Publish Drive message
        heading = data.angle_min + data.angle_increment*destination_i
        if abs(heading) <= 20*np.pi/180:
            if abs(heading) <= 10*np.pi/180:
                velocity = 0.75
            else:
                velocity = 0.40
        else:
            velocity = 0.20
        ack_msg = AckermannDriveStamped()
        ack_msg.drive.speed = velocity*.8
        ack_msg.drive.steering_angle = heading
        self.publisher_.publish(ack_msg)


def main(args=None):
    rclpy.init(args=args)
    print("WallFollow Initialized")
    reactive_node = ReactiveFollowGap()
    rclpy.spin(reactive_node)

    reactive_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
