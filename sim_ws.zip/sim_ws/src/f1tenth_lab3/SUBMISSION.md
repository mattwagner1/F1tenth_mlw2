# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [FILL ME IN](https://youtu.be/cuQKrBCQjhI)

Hardware (group) : [FILL ME IN](https://youtube.com/shorts/i32GX4bEYwo)
